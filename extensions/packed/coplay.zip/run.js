(function () {
    var coplay = window.coplay;
    if (!coplay) {
        return;
    }

    coplay.init();
})();
